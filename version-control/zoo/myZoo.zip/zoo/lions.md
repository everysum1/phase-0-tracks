#Lions

*Timon
*Pumbaa
*Rafiki
*Nala
*Simba
*Scar
*Mufasa
*Sharabi