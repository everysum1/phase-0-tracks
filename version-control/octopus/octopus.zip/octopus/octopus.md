#Octopus

Name: Squidworm
Age: 88
Hat: Cowboy
Glasses: Heart-shaped sunglasses